# CoreWar Project 42 School & UNIT Factory

-----[Project - CoreWar]-----

The Members Team's:
1. Artem Makhinya
2. Timofii Vertohradov
3. Vladislav Makahonov