/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amakhiny <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 22:18:18 by amakhiny          #+#    #+#             */
/*   Updated: 2017/10/30 22:18:22 by amakhiny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putnbr_fd(int n, int fd)
{
	char	num;

	if (ft_minint(n))
		ft_putstr_fd("-2147483648", fd);
	else if (n < 0)
	{
		n = -n;
		ft_putchar_fd('-', fd);
		ft_putnbr_fd(n, fd);
	}
	else if (n >= 10)
	{
		num = (n % 10) + '0';
		ft_putnbr_fd(n /= 10, fd);
		ft_putchar_fd(num, fd);
	}
	else
		ft_putchar_fd(n + '0', fd);
}
